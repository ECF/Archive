package org.eclipse.ecf.android;

import android.os.Parcel;

public class SharedObject implements ISharedObject {

	public void dispose(ID containerID) {
		// TODO Auto-generated method stub

	}

	public void handleEvent(Event event) {
		// TODO Auto-generated method stub

	}

	public void handleEvents(Event[] events) {
		// TODO Auto-generated method stub

	}

	public void init(ISharedObjectConfig initData)
			throws SharedObjectInitException {
		// TODO Auto-generated method stub

	}


	public int describeContents() {
		// TODO Auto-generated method stub
		return 0;
	}

	public void writeToParcel(Parcel dest, int flags) {
		// TODO Auto-generated method stub
		
	}

	public Object getAdapter(Class class1) {
		// TODO Auto-generated method stub
		return null;
	}

}
