package org.eclipse.ecf.android;

import android.app.Application;

public class BootECF extends Application {



	

}
