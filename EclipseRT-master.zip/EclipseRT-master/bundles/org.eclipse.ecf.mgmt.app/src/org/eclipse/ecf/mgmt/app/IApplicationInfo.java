/*******************************************************************************
 * Copyright (c) 2010 Composent, Inc. and others. All rights reserved. This
 * program and the accompanying materials are made available under the terms of
 * the Eclipse Public License v1.0 which accompanies this distribution, and is
 * available at http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *   Composent, Inc. - initial API and implementation
 ******************************************************************************/
package org.eclipse.ecf.mgmt.app;

import java.util.Map;

public interface IApplicationInfo {

	public String getId();

	public String getName();

	public Map getProperties();

	public boolean isLocked();

	public boolean isLaunchable();

	public boolean isVisible();

}
