AIM(R) Software Development Kit

Copyright 1998-2008 AOL LLC.  All rights reserved.
Distributed only to persons who have agreed to the license agreement.

This SDK enables development of client software applications which connect to the AIM network, and plugins for those applications.

Begin by browsing the tutorials and sample code, and join the discussions at <http://dev.aol.com/>.
