package org.remotercp.filetransfer.receiver;

public class ImageKeys {

	private ImageKeys() {
		// nothing to do
	}

	public static final String FILETRANSFER = "icons/files.png";

}
