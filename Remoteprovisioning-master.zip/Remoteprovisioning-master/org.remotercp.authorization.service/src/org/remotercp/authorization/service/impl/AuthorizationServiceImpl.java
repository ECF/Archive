package org.remotercp.authorization.service.impl;

import org.eclipse.ecf.core.identity.ID;
import org.remotercp.authorization.domain.service.IAuthorizationService;

public class AuthorizationServiceImpl implements IAuthorizationService{

	public boolean isAdmin(ID userID) {
		// TODO Auto-generated method stub
		return true;
	}

}
