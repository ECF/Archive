package org.remotercp.login;

public class ImageKeys {

	private ImageKeys() {
	};

	public static final String USER_LOGIN = "icons/identity.png";
}
