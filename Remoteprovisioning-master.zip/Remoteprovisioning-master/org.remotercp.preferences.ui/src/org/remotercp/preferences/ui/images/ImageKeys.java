package org.remotercp.preferences.ui.images;

public class ImageKeys {
	
	private ImageKeys(){
		
	}
	
	public final static String ARROW_LEFT ="icons/arrow_left_22x22.png";

}
