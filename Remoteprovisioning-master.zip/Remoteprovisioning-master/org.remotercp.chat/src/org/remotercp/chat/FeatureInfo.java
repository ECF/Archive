package org.remotercp.chat;

public enum FeatureInfo {
	NAME, VERSION, ID
}
