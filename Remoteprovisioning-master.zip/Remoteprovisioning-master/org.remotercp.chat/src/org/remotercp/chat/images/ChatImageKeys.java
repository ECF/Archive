package org.remotercp.chat.images;


public class ChatImageKeys {

	private ChatImageKeys() {
		// nothign to do
	}

	public static final String CHAT = "icons/start_chat_32x32.png";
}
