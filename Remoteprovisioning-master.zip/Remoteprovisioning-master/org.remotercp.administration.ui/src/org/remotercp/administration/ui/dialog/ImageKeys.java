package org.remotercp.administration.ui.dialog;

import java.io.File;

public class ImageKeys {

	private ImageKeys() {

	}

	public static final String WARNING = "icons" + File.separator
			+ "warning.png";

}
