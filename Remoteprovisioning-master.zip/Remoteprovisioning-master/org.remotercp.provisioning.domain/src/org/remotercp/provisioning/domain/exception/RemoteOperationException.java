package org.remotercp.provisioning.domain.exception;

public class RemoteOperationException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = -4123031471281818497L;

	public RemoteOperationException(String message){
		super(message);
	}
	
}
